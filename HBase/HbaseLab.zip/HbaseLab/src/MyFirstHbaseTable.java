import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.io.compress.Compression.Algorithm;
import org.apache.hadoop.hbase.util.Bytes;


import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;


public class MyFirstHbaseTable {

	private static final String TABLE_NAME = "user";
	private static final String CF_DEFAULT = "personal_details";
	private static final String CF_PROF = "prof_details";
    
	public static void main(String... args) throws IOException {

		Configuration config = HBaseConfiguration.create();

		try (Connection connection = ConnectionFactory.createConnection(config);
				Admin admin = connection.getAdmin()) {
			HTableDescriptor table = new HTableDescriptor(
					TableName.valueOf(TABLE_NAME));
			table.addFamily(new HColumnDescriptor(CF_DEFAULT)
					.setCompressionType(Algorithm.NONE));
			table.addFamily(new HColumnDescriptor(CF_PROF));

			//System.out.print("Creating table.... ");
			System.out.print("Creating table.... " + table.getNameAsString());

			//System.out.println(admin);
			if (admin.tableExists(table.getTableName())) {
				admin.disableTable(table.getTableName());
				admin.deleteTable(table.getTableName());
			}
			admin.createTable(table);

			Table tableUser = connection.getTable(TableName.valueOf(TABLE_NAME));

	        Put put = new Put(Bytes.toBytes("1"));
	        put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("Name"),
	                Bytes.toBytes("John"));
	        put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("City"),
	                Bytes.toBytes("Boston"));
	        put.addColumn(Bytes.toBytes(CF_PROF), Bytes.toBytes("Designation"),
	                Bytes.toBytes("Manager"));
	        put.addColumn(Bytes.toBytes(CF_PROF), Bytes.toBytes("Salary"),
	                Bytes.toBytes("150000"));
	        tableUser.put(put);
	        

			    put = new Put(Bytes.toBytes("2"));
				put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("Name"), Bytes.toBytes("Mary"));
				put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("City"), Bytes.toBytes("New York"));
				put.addColumn(Bytes.toBytes(CF_PROF), Bytes.toBytes("Designation"), Bytes.toBytes("Sr.Engineer"));
				put.addColumn(Bytes.toBytes(CF_PROF), Bytes.toBytes("salary"), Bytes.toBytes("130000"));
				tableUser.put(put);

				tableUser.put(put);
			    put = new Put(Bytes.toBytes("3"));
				put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("Name"), Bytes.toBytes("Bob"));
				put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("City"), Bytes.toBytes("Fremont"));
				put.addColumn(Bytes.toBytes(CF_PROF), Bytes.toBytes("Designation"), Bytes.toBytes("Jr.Engineer"));
				put.addColumn(Bytes.toBytes(CF_PROF), Bytes.toBytes("salary"), Bytes.toBytes("90000"));
				tableUser.put(put);
				
			System.out.println(" Done!");
		}
	}
}
